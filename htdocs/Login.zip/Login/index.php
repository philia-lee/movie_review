<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V14</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	<?php

	include("../session.php");
	include("../addpoint.php");
	if(empty($_POST['logout'])==FALSE){
	  if($_POST['logout']==10){
	session_unset();     // 현재 연결된 세션에 등록되어 있는 모든 변수의 값을 삭제한다
	session_destroy();  //현재의 세션을 종료한다
	/*
	 echo"
	 <script>
	     alert('로그아웃되었습니다');
	     location.replace('이동할페이지');
	 </script>
	 ";
	 */
	  }
	}
	if(isset($_SESSION["login_ch"])==FALSE){
	/*
	echo "<form action=\"./\" method=\"post\">
	ID:<input type=text name=id />
	<br>PW:<input type=password name=pw /><br>
	<input type=\"submit\" value=\"로그인\"/>
	</form>

	<form action=\"./register.php\" method=\"post\">
	<input type=\"submit\" value=\"회원가입\"/>
	</form>";
	*/
	}else{
	  $userfile=file("../user/user".$_SESSION['login_num'].".txt");
	  echo "\"".trim($userfile[2])."\""."님 반갑습니다.<br>포인트:".trim($userfile[4])."<br>";
	  echo "<form action=\"./\" method=\"post\">
	  <input type=hidden name=logout value=10 />
	  <input type=\"submit\" value=\"로그아웃\"/>
	  </form>";
	}
	 ?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-85 p-r-85 p-t-55 p-b-55">
				<form class="login100-form validate-form flex-sb flex-w" action="../mainpage/main.php" method="post">
					<span class="login100-form-title p-b-32">
						Account Login
					</span>

					<span class="txt1 p-b-11">
						아이디
					</span>
					<div class="wrap-input100 validate-input m-b-36" data-validate = "Username is required">
						<input class="input100" type="text" name="id" >
						<span class="focus-input100"></span>
					</div>

					<span class="txt1 p-b-11">
						비밀번호
					</span>
					<div class="wrap-input100 validate-input m-b-12" data-validate = "Password is required">
						<span class="btn-show-pass">
							<i class="fa fa-eye"></i>
						</span>
						<input class="input100" type="password" name="pw" >
						<span class="focus-input100"></span>
					</div>

					<div class="flex-sb-m w-full p-b-48" style="padding-bottom:24px;">
						<div class="contact100-form-checkbox">
							<input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
							<label class="label-checkbox100" for="ckb1">
								Remember me
							</label>
						</div>

						<div>
							<a href="#" class="txt3">
								회원가입
							</a>
						</div>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn"style="margin: 0 auto;">
							Login
						</button>
					</div>

				</form>
			</div>
		</div>
	</div>


	<div id="dropDownSelect1"></div>

<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
